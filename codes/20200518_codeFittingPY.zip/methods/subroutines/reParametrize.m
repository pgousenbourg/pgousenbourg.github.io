function tOut = reParametrize(t,dataCoords)
% REPARAMETRIZE changes the vector t according to the dataCoords.
%
%    TOUT = REPARAMETRIZE(T,DATACOORDS) reparametrizes T such that the
%    DATACOORDS correspond to integer times i = 0,1,2,... DataCoords and
%    TOUT must be 1D-vectors.
%
%    XOUT = REPARAMETRIZE(X,DATACOORDS) reparametrize X the 2-matrix 
%    X such that DATACOORS coorespond to interger times as well. 
%    DATACOORDS must be a vector of coordinates.
%
%    EXAMPLES:
%      t = [1,2,3,4,5] and dataCoords = [1,3,5];
%      Then, tOut = reParametrize(t,dataCoords) will return
%      tOut = 
%         [0,0.5,1,1.5,2].
%
%      X = [1,2,3,4,5;   and dataCoords = [1,2];
%           1,2,3,4,5]
%      Then Xout = reParametrize(X,dataCoords) will reparametrize as
%      Xout = [0,0.25,0.5,0.75,1;
%              0,0.25,0.5,0.75,1].
%      
% Original author: 
%   Pierre-Yves Gousenbourger, Feb. 27, 2018
% Contributors: 
%
% Change log:
%   Oct. 3, 2019 (PYG):
%      Generalization to 2D.
%
    % preprocessing flatten the matrix if needed
    sT = size(t); 
    t = t(:);
    
    % reshaping process
    p = length(t);
    tt = zeros(sT);
    for i = 1:p
      % detect the closest data points
      idx = find(dataCoords - t(i) >= 0);
      if isempty(find(dataCoords == t(i))) % data coord not at t(i)
        t1 = dataCoords(idx(1)-1);
        t2 = dataCoords(idx(1));
        tt(i) = (t(i) - t1)./(t2 - t1) + (idx(1)-2);
      else
        tt(i) = idx(1)-1;
      end
    end
    
    % postprocessing if needed, reshape tt at the matrix size
    tOut = reshape(tt,sT);
end
