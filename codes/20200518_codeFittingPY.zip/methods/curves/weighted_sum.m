function x = weighted_sum(w,y,M,u)
% Computes a weighted sum.
% 
% function x = weighted_sum(w,y)
% Computes the weighted sum x = sum_i ( w_i*y_i ). More specifically, it
% solves the problem
%      x = argmin_z sum_i ( w_i * dist(z,y_i) )
%
% Input: w, a vector of weights;
%        y, the data points in a m-by-n-by-p, where [m,n] is the
%           the dimension of the space and p is the number of points.
%           length(w) must be the same size as p.
%        M, the manifold structure containing differential geometry.
% 		 u, the reference point as m-by-n matrix. If not given, it will
% 			be the first point.
%
% Output: x, the summary vector of size [m,n].
%
% Original author: 
%   Estelle Massart, Oct. **, 2016
% Contributors: 
%	Pierre-Yves Gousenbourger, Oct. 17, 2016
%
% Change log:
% 	Oct. 17, 2016 (PYG):
%      Preparation of the document for integration into the framework
%      for approximation methods with Bezier functions.
%   Oct. **, 2016 (EM):
%      First version.
	
	
	if nargin < 3
		error('Not enough input arguments');
	else if nargin < 4
		u = y(:,:,1);		
	end
	
	% TO_DO_ESTELLE_MASSART
	x = zeros(size(y(:,:,1)));
	
	% Project on the tangent space of u (if defined)
	for i = 1:size(y,3)
		y(:,:,i) = M.log(u,y(:,:,i));
	end
	
	% Weighted mean
	for i = 1:length(w)
		x = x + w(i)*y(:,:,i);
	end
	
	% Back projection
	x = M.exp(u,x);
	
end
