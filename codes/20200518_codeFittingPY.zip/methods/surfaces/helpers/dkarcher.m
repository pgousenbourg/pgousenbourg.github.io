function dy = dkarcher(M,x,b,w)
% Computes the gradient of the Riemannian center of mass of the points b 
% weighted by w.
%
% function dy = dkarcher(M,x,b,w)
%    returns dy, the gradient of the Karcher mean with respect to x.
%
% Original author: 
% 	Pierre-Yves Gousenbourger, Nov. 07, 2018.
% Contributors: 
%   ***
% Change log:
% 	Nov. 07, 2018 (PYG) - Original file.
% 	Mar. 26, 2019 (PYG) - Corrections to keep the grad in the tangent space.
	
	b = b(:);
	w = w(:);
	
	elems = length(b);
	assert(elems == length(w),'The dimension of b and w must agree.');
	
	dy = zeros(size(M.randvec(x)));
	for i = 1:elems;
		dy = dy - 2*w(i)*M.log(x,b{i});
	end
end
