function bool = isParent(i,domain)
% Checks if the ith line of domain is a parent of other domains.
%
% function isParent(DOMAIN,I)
%    Returns a logical number saying if the I^th line of DOMAIN has
%    associated childrens in DOMAIN.
%    If I is a vector, then the function will return a vector of
%    booleans checking every entry of I.
%
% See also: refineDomain, findDomain, makeDomain
%
% Original author: 
% 	Pierre-Yves Gousenbourger, Jan. 08, 2020.
% Contributors: 
%
% Change log:
% 	Jan. 08, 2020 (PYG) - First version.

  % defense
  assert(size(domain,2) == 5,'isParent:dimCheck','domains must have five columns');
  assert(isempty(find(i <= 0)),'isParent:i','i must be greater than zero');
  
  % parameters
  si = size(i);
  i = i(:);
  
  bool = zeros(size(i));
  for k = 1:length(i)
    bool(k) = ~isempty(find(domain(:,1) == i(k)));
  end
  bool = reshape(bool,si);
end
