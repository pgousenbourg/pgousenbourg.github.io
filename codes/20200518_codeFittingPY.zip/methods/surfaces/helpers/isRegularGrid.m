function bool = isRegularGrid(rootCoords)
% Checks if the grid given in ROOTCOORDS is regular.
%
% function isRegularGrid(ROOTCOORDS)
%    Returns a logical number saying if ROOTCOORDS specifies a regular
%    grid or not. ROOTCOORDS must be a [px2] matrix.
%
% See also: makeDomain
%
% Original author: 
% 	Pierre-Yves Gousenbourger, Jan. 07, 2020.
% Contributors: 
%
% Change log:
% 	Jan. 07, 2020 (PYG) - First version.

  % defense
  assert(size(rootCoords,2) == 2,'isRegularGrid:dimCheck','rootCoords must have two columns');
  
  % boolean return. Each occurence must appear the same number of time.
  bool = (isscalar(occurInArray(rootCoords(:,1))) && isscalar(occurInArray(rootCoords(:,2))));
end

% Extracts the number of occurences that appear in the same vector.
function A = occurInArray(X)
  X = hist(X(:));
  X = hist(X(X>0));
  A = X(X>0);
end
