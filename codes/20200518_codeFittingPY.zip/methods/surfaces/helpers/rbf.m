function y = rbf(r)
% Returns the value of the Radial Basis Function, used for Thin Plate
% Splines, at ray r.
%
% function y = rbf(r)
%    returns y, the value of the RBF at ray r, given by
%    rbf(t) = | 1/(16pi) r^2 log r^2  if r > 0
%             | 0                     else
  assert(length(r(:)) == 1,'r must be a scalar');
  if r > 0
    y = (1./(16*pi))*(r^2)*log(r^2);
  else
    y = 0;
  end
end
