function coherenceOfInputs(vars);
% Checks the consistency of the inputs for blendedSurfaces.
%
% function coherenceOfInputs(vars)
%    Checks the coherence between pairs of inputs from the vars.
%
% Original author: 
% 	Pierre-Yves Gousenbourger, Mar. 24, 2020.
% Contributors: 
%
% Change log:
% 	Mar. 24, 2020 (PYG) - First version.

    
  % --- coherence between dataCoords & dataPoints ----------------------
  assert(length(vars.dataPoints) == size(vars.dataCoords,1),'There must be as many dataPoints as dataCoords');
  
  % --- coherence between rootCoords & rootPoints ----------------------
  assert(length(vars.options.rootPoints) == size(vars.options.rootCoords,1),'There must be as many rootPoints as rootCoords');
  
  % --- coherence between dataPoints & rootPoints ----------------------
  K = size(vars.dataPoints{1});
  for i = 1:length(K)
    assert(size(vars.options.rootPoints{1},i) == K(i),'dataPoints and rootPoints must belong to the same space');
  end
  
  clear K;
  
  % --- coherence between X,Y and dataCoords, rootCoords ---------------
  minX = min(vars.options.rootCoords(:,1)); maxX = max(vars.options.rootCoords(:,1));
  minY = min(vars.options.rootCoords(:,2)); maxY = max(vars.options.rootCoords(:,2));
  X = vars.X(:); Y = vars.Y(:);
  assert(min(X) >= minX && max(X) <= maxX && min(Y) >= minY && max(Y) <= maxY,'X and Y must be in the domain set by rootCoords');
  
  clear minX minY maxX maxY X Y;
  
  % --- coherence between reconstructionMethod and generationMethod ----
  assert(strcmp(vars.options.reconstructionMethod,vars.options.generationMethod),'generation and reconstruction should be compatible');
  
  % --- coherence between domains and rootCoords -----------------------
  doms = vars.options.domains(2:5);
  doms = doms(:);
  rC   = length(vars.options.rootCoords);
  assert(max(doms) <= rC && min(doms) >= 0, 'domains indexes must correspond to existing rootCoords');
  clear rC doms;
end
