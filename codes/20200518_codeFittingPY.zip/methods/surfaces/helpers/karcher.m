function y = karcher(M,x,b,w)
% Computes the Riemannian center of mass of the points b weighted by w.
%
% function y = karcher(M,x,b,w)
%    returns y, the Karcher mean given by
%            y = sum_i w_i dist(b_i,x),
%    where dist is the geodesic distance. b is a cell of the same
%    dimension of w.
%
% Original author: 
% 	Pierre-Yves Gousenbourger, Nov. 07, 2018.
% Contributors: 
%   ***
% Change log:
% 	Nov. 07, 2018 (PYG) - Original file.

	b = b(:);
	w = w(:);
	
	elems = length(b);
	assert(elems == length(w),'The dimension of b and w must agree.');
	
	y = 0;
		
	for i = 1:elems;
    %size(x)
    %size(b{i})
		y = y + w(i)*M.dist(x,b{i}).^2;
	end
end
