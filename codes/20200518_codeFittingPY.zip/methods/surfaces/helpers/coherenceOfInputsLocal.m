function coherenceOfInputsLocal(vars);
% Checks the consistency of the inputs for localSurface.
%
% function coherenceOfInputsLocal(vars)
%    Checks the coherence between pairs of inputs from the vars.
%
% Original author: 
% 	Pierre-Yves Gousenbourger, Mar. 24, 2020.
% Contributors: 
%
% Change log:
% 	Mar. 24, 2020 (PYG) - First version.
%   Mar. 25, 2020 (PYG) - Modification for localSurface

    
  % --- coherence between dataCoords & dataPoints ----------------------
  assert(length(vars.dataPoints) == size(vars.dataCoords,1),'There must be as many dataPoints as dataCoords');
    
  % --- coherence between dataPoints & rootPoints ----------------------
  K = size(vars.dataPoints{1});
  for i = 1:length(K)
    assert(size(vars.rootPoint,i) == K(i),'dataPoints and rootPoint must belong to the same space');
  end
  
  clear K;
  
  % --- coherence between reconstructionMethod and generationMethod ----
  assert(strcmp(vars.options.reconstructionMethod,vars.options.generationMethod),'generation and reconstruction should be compatible');
  
end
