function b = simple_tensorization(M, dataPoints, A, threshold)
% Computes the control points of a C^2-Bezier spline in R^n.
%
% function b = simple_tensorization(M,dataPoints,A,threshold)
%    returns b, a cell containing data points of a C2 Bezier spline in
%    the Euclidean space. The manifold M is used to verify the distance
%    of the points wrt the geodesic. A is the matrix that generates the
%    control points. Threshold limits the input from the matric.
%
% Original author: 
% 	Pierre-Yves Gousenbourger, Nov. 02, 2015.
% Contributors: 
%	Paul Striewski.
% Change log:
% 	Nov. 05, 2018 (PYG) - Integration to the framework.
% 	Nov. 07, 2018 (PYG) - Integration of the Manopt framework.

	m = length(dataPoints);

	b = cell(3*m-2,1);

	for i = 1:m-1
	for k = 0:3
		b{3*(i-1)+k+1} = bki(M,dataPoints,A,k,i,threshold);
	end
	end

	% Sanity checks - Interpolation conditions
	for i=4:3:3*m-3
		av = M.pairmean(b{i-1}, b{i+1}); 
		dist = acos(dot(av,b{i}));
		if dist > 1e3
			warning('The distance between average and cp is high: %d\n', dist);
		end
	end
end
