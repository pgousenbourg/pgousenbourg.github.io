function idx = findRoot(X,Y,rootCoords)
% Computes the rootPoint index associated with the position (X,Y).
%
% idx = findRoot(X,Y,ROOTCOORDS)
%    finds the index of the rootCoord at position (X,Y). If none is
%    found, then an empty vector is returned.
%
% Inputs:  X,Y (scalars), positions in the domain.
%          ROOTCOORDS, a matrix with two columns with the (X,Y)-
%           positions of the grid coordinates.
% 
% Outputs: idx, the index of the rootCoord, in ROOTCOORDS.
%
% See also: findDomain, refineDomain, findNeighbors
%
% Original author: 
% 	Pierre-Yves Gousenbourger, Jan. 09, 2020.
% Contributors: 
%
% Change log:
% 	Jan. 09, 2020 (PYG) - First version.
%   Jan. 13, 2020 (PYG) - Defense and proper function.

  % defense
  assert(size(rootCoords,2) == 2,'findRoot:dimCheck','rootCoords should have only 2 columns');
  assert(isscalar(X) && isscalar(Y),'findRoot:XY','X and Y must be scalar');
  
  % parameters
  tol = 1e-8;
  
  % find the indexes
  idx = find(abs(rootCoords(:,1) - X) < tol);
  if ~isempty(idx)
    idx = idx(find(abs(rootCoords(idx,2) - Y) < tol));
  end
end
