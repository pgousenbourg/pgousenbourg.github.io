function y = bezierSurfaceEuclidean(varargin)
% Computes a Bezier surace on the Euclidean space.
%
% function y = bezierSurfaceEuclidean(b,t1,t2)
%   returns y, the value of the Euclidean Bezier curve at t1 and t2. 
%   The curve is driven by the points b (cell).
%
% Original author: 
% 	Pierre-Yves Gousenbourger, May. 13, 2019.
% Contributors: 
%   ***
% Change log:
% 	May. 13, 2019 (PYG) - Original file.

  % create the parser
  ip = inputParser();
  addRequired(ip,'b');
  addRequired(ip,'t1');
  addRequired(ip,'t2');

  % parse the parser as a structure.
  parse(ip, varargin{:});
  vars = ip.Results;
  
  % variables
  b  = vars.b;
  t1 = vars.t1;
  t2 = vars.t2;
  
  assert(t1 >= 0 && t1 <= 1,'t1 must be between 0 and 1');
  assert(t2 >= 0 && t2 <= 1,'t2 must be between 0 and 1');
  
  deg = size(b,1)-1;
  
  % Curve reconstruction
  w = weights_bern(deg,t1,t2);
  w = w(:);
  b = b(:);
  
  % Weighted mean of the control points
  y = zeros(size(b{1}));
  for i = 1:length(b)
    y = y + w(i).*b{i};
  end
  
end

