function y = decasteljau1d_c1(M,b,t,patch,maxPatch)
% Returns the value of a Bezier function driven by control points b at
% time t, continuously connecting with other patches in a 2D config.
%
% function y = decasteljau(M,b,t)
%    returns y, the value of the manifold valued Bezier function on M,
%    controlled by the control points b of M, and at time t (scalar). 
%    y is a vector of the dimension of the manifold.
% 
% Input: M, the manifold structure (from manopt framework) containing
%         the elements of differential geometry.
%        b, the control points of the Bezier function (evaluated in M).
%         the control points are stored in a 1d-cell.
%        t, the scalar time at which the spline is evaluated.
%        patch, the current patch of the 2D surface
%        maxPatch, the maxPatches in the given direction in the 2D surface.
%                  
% Output: y, the value of the spline at t.
%
% Original author: 
%   Pierre-Yves Gousenbourger, Oct. 19, 2016
% Contributors: 
%
% Change log:
% 	Oct. 19, 2016 (PYG):
%      Firts version
%   Feb. 21, 2019 (PYG):
%      Modification to insert b-cell.
    
  assert(t <= 1 & t >= 0,'t must be between [0,1]');
  
  % tool
  geo_map = @(x,y,t) M.exp(x,t*M.log(x,y));
  deg = length(b)-1;
  
  % First and last step if we are inside a patch
  if patch > 1; b{1} = M.pairmean(b{1},b{2}); end;
  if patch < maxPatch; b{end} = M.pairmean(b{end-1},b{end}); end;
  
  % De Casteljau proceeds normally
  y = b;
	for i = 1:deg
		for j = 1:deg-i+1
			y{j} = geo_map(y{j},y{j+1},t);
		end
	end
	
	y = y{1};
end
