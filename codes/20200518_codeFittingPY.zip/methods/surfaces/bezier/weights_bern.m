%% WEIGHTS_BERN -
%       Computation of weights based on the Bernstein representation

function w = weights_bern(deg,t1,t2)
	b = zeros(deg+1,1);
	c = b;
	for i = 1:deg+1
		b(i) = bern(deg,i-1,t1);
		c(i) = bern(deg,i-1,t2);
	end
	w = b*c';
end
