%% WEIGHTS_BERN_C1 -
%       Computation of weights based on the Bernstein representation
% 		for C^1 curves.

function b = weights_bern_c1(patch,deg,t,maxPatch)
	b = zeros(deg+1,1);
	
	
	% Extreme left (or down)
	if patch == 1
		b(1) = bern(deg,0,t);
		b(2) = bern(deg,1,t);
	else
		b(1) = 1/2*bern(deg,0,t);
		b(2) = bern(deg,1,t) + b(1);
	end
	
	% Inner points
	for i = 3:deg-2
		b(i) = bern(deg,i-1,t);
	end
	
	
	% Extreme right (or up)
	if patch == maxPatch
		b(deg)   = bern(deg,deg-1,t);
		b(deg+1) = bern(deg,deg,t);
	else
		b(deg+1) = 1/2*bern(deg,deg,t);
		b(deg)   = bern(deg,deg-1,t) + b(deg+1);
	end
end
