function y = decasteljau2d_mean(varargin)
% Computes a Bezier curve with a 2d-karcher-mean approach.
%
% function y = decasteljau2d_mean(M,b,t1,t2)
%   returns y, the value of the Riemannian Bezier curve on the manifold
%   M at t1 and t2. The curve is driven by the points b (cell).
%
% Original author: 
% 	Pierre-Yves Gousenbourger, Feb. 21, 2019.
% Contributors: 
%   ***
% Change log:
% 	Feb. 21, 2019 (PYG) - Original file.

  % create the parser
  ip = inputParser();
  addRequired(ip,'M');
  addRequired(ip,'b');
  addRequired(ip,'t1');
  addRequired(ip,'t2');

  % parse the parser as a structure.
  parse(ip, varargin{:});
  vars = ip.Results;
  
  % variables
  M  = vars.M;
  b  = vars.b;
  t1 = vars.t1;
  t2 = vars.t2;
  
  deg = size(b,1)-1;
  
  % Curve reconstruction
  w = weights_bern(deg,t1,t2);
  
  % Manopt solution for the Karcher mean
  model.M = M;
  model.cost = @(x) karcher(M,x,b,w);
  model.grad = @(x) dkarcher(M,x,b,w);
  
  options.verbosity = 0;
  warning('off', 'manopt:getHessian:approx') 
  %checkgradient(model); pause
  
  % Solution
  y = trustregions(model,[],options);
end

