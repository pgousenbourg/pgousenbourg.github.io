function tangentValues = pointsLifting(M,rootPoints,points)
% Lifts the points in the tangent space of the last element of rootPoints 
% by transporting the points through all elements of rootPoints.
%
% function tangentValues = pointsLifting(M,rootPoints,points)
%    returns tangentValues, the representation in T_{rootPoints{end}}M 
%    of the points, lifted thanks to the M.log operator of M, a manifold
%    manopt-structure, and transported through M.transp.
%    The points are first lifted in the first element of rootPoints,
%    and then the tangent values are transported from element to element
%    of rootPoints, and the distance between each rootPoint is
%    accumulated at each transport.
%
% inputs:  M, a manopt manifold-structure containing the M.log operator.
%          rootPoints, a m-cell of point on the manifold M.
%          points, [DIM]-cell of points to be lifted to the tangent 
%            space at rootPoint.
%
% outputs: tangentValues, a [DIM]-cell containing the lifted version
%            the points to the tangent spaces at root.
%
% Original author: 
% 	Pierre-Yves Gousenbourger, Jan. 22, 2020.
% Contributors: 
%
% Change log:
% 	Jan. 22, 2020 (PYG) - First version.

  % defense
  if ~iscell(rootPoints)
    temp = rootPoints;
    rootPoints = cell(1,1);
    rootPoints{1} = temp;
    clear temp;
  end
  if ~iscell(points)
    temp = points;
    points = cell(1,1);
    points{1} = temp;
    clear temp;
  end
  
  %rootPoints
  assert(isvector(rootPoints),'surfaceFitting:vectorCell','rootPoints must be a scalar or vectorial cell');
  
  % parameter
  sPoints     = size(points);
  sRootPoints = size(rootPoints);
  if sRootPoints > 1
    if isfield(M,'isotransp')
      tp = M.isotransp;
    else
      tp = M.transp;
    end
  end
  
  % method
  points = points(:);
  tangentValues = cell(size(points));
  for j = 1:length(points)
    temp = M.log(rootPoints{1},points{j});
    for k = 2:length(rootPoints)
      temp = tp(rootPoints{k-1},rootPoints{k},temp) + M.dist(rootPoints{k-1},rootPoints{k});
    end
    tangentValues{j} = temp;
    clear temp;
  end
  tangentValues = reshape(tangentValues,sPoints);
end
