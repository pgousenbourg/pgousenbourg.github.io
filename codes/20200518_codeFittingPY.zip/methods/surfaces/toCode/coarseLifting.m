function varargout = coarseLifting(varargin)
% Lifts the data points by summarizing far data points by planes.
%
% function X = coarseLog()
%    returns X, description.
%
% More explanations.
%
% Usage.
%
% Original author: 
% 	Pierre-Yves Gousenbourger, Dec. 16, 2019.
% Contributors: 
%
% Change log:
% 	Dec. 16, 2019 (PYG) - First version.


end
