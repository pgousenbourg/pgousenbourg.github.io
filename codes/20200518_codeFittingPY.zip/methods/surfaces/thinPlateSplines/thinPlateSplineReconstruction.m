function tps = thinPlateSplineReconstruction(X,Y,repr,t)
% Returns the Euclidean Thin Plate Spline driven by a and d at times
% X and Y.
%
% function tps = thinPlateSplineReconstruction(X,Y,repr,t)
%    returns tps, the value of the Euclidean Thin Plate Spline driven 
%    by the coefficients repr.a and repd.d, evaluated at (X,Y), on the 
%    time set t.
%
% inputs:  X,Y are time parameters contained in a [p,q] matrix;
%          repr. is a structure containing 
%            - repr.d has [ndp,m,n] entries (where ndp was previously the
%              number of data points to fit);
%            - repr.a has [3,m,n] entries.
%          t is the time set (this is a [ndp,2] matrix)
%
% outputs: tps is a [p,q,m,n] matrix.
%
% Original author: 
% 	Pierre-Yves Gousenbourger, Dec. 17, 2019.
% Contributors: 
%
% Change log:
% 	Dec. 17, 2019 (PYG) - First version.

  % parameters and defense
  %[mt,nt] = size(X);
  
  a = repr.a;
  d = repr.d;
  
  if isvector(X)
    sX = length(X);
  else
    sX = size(X);
  end
  X = X(:);
  Y = Y(:);
  assert(length(X) == length(Y),'surfaceFitting:dimCheck','X and Y must be of same size');
  
  [ndp,m,n] = size(d);
  assert(3 == size(a,1),'TPSBuild:Asize','a must contain only 3 rows');
  assert(m == size(a,2) && n == size(a,3),'TPSBuild:ADdimCheck','a and d must contain objects of same dimension');
  
  % construction of the solution
  %tps = zeros(mt*nt,m,n);
  tps = zeros(prod(sX),m,n);
  for i = 1:length(X)
    temp = zeros(1,m,n);
    ti = [X(i),Y(i)];
    % radial basis part
    for j = 1:ndp
      r = norm(t(j,:) - ti);
      temp = temp + d(j,:,:).*rbf(r);
    end
    % affine complement
    tps(i,:,:) = temp + a(1,:,:) + a(2,:,:).*X(i) + a(3,:,:)*Y(i);
  end
  tps = reshape(tps,[sX,m,n]);
end
