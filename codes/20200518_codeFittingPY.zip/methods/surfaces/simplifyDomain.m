function simpleDomains = simplifyDomain(domains)
% Simplifies the domain by removing parents.
%
% function simpleDomains = simplifyDomain(domains)
%    returns simpleDomains, a simplified version of domains where all
%    the parents are removed.
%
% Inputs:  domains is a [px5] matrix.
% Outputs: simpleDomains, a [qx5] matrix where there is no parent
%          anymore (every parent line is now 0).
%
% Original author: 
% 	Pierre-Yves Gousenbourger, Jan. 16, 2020.
% Contributors: 
%
% Change log:
% 	Jan. 16, 2020 (PYG) - First version.


  % defense
  assert(size(domains,2) == 5,'simplifyDomain:dimCheck','Domains must have 5 columns');
  
  simpleDomains = [];
  for i = 1:size(domains,1)
    if ~isParent(i,domains)
      simpleDomains = [simpleDomains; 0 domains(i,2:5)];
    end
  end
end
