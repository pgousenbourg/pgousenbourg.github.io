%% ---------------------------------------------------------------------
%                        EXAMPLE FILE EUCLIDEAN
% ----------------------------------------------------------------------
%
% This file is a file of a running example of unidimentionnal 
% interpolation on manifolds using Bezier paths. 
% These paths are certified to be C^1 in the sense
% of the manifold.
% 
% Manifold: Sphere space.
% 
% Author: Pierre-Yves Gousenbourger.
% Version: 	20 mar 2015 - First version.
% 			14 mar 2018 - (RIP S.Hawking) Inclusion of the new code design

close all;
clear all;
clc;

% Paths

cd manopt;
addpath(genpath(pwd));
cd ..;
addpath(genpath([pwd,'/tools']));


disp('=====================================================');
fprintf('Bezier interpolation tool: %26s\n','test example');
disp('-----------------------------------------------------');


% The whole problem is stored in a structure.
% The manifold is described in another structure created by
% euclideanfactory(n). This manifold structure contains namely elements 
% of differential geometry. 


% Step 0 : Some data points

	addpath([pwd,'/data_points']);
	problem.data = data_points('sphere','triangle');
	n 	= size(problem.data,3);			% number of data points	
	t = linspace(0,n-1,100); 			% sampling


% Step 1: Create the problem structure.

	manifold  = spherefactory(3);
	problem.M = manifold;
	problem.space = 'sphere';
	fprintf('Manifold: %43s\n',problem.M.name());


% Step 2 : Computation of the control points
%
% Here, it is possible to choose different methods to compute the
% control points:
% 	- [control_points_arnould] Based on Arnould2015.
% 	  It computes the control points with an extrinsic method and
% 	  optimizes the mean square acceleration of the curve as well as the
% 	  velocity of the curve.
%
% 	- [control_points_gousenbourger] Based on Gousenbourger2014.
% 	  It computes the control points with an intrinsic method and
% 	  optimizes the mean square acceleration of the curve. The velocity
% 	  of the curve must be specified at interpolation points with
% 	  parameter 'velocity':
% 			velocity = 'orthog';
% 			velocity = 'parallel'.
%
%  	- [control_points_bspline] Based on Gousenbourger2016
% 	  It computes the control points with an extrinsic method using the
%     Euclidean definition of the Bsplines. Namely, in R^n, it returns
%     the unique natural cubic B-spline minimizing the acceleration of
%     the curve and with zero acceleration at the beginning and end of
%     the curve.
%
% In the Euclidean space, all these techniques are identical.

	tStart = tic;
	
	% Generation
	% Uncomment the line with the chosen method.
	
	% Gousenbourger2014
	%problem.control = cp_gousenbourger(problem,'parallel');
	
	% Arnould2015
	problem.control = cp_arnould(problem);
	
	disp(' ');
	
	fprintf('Control points computed in: ');  
	fprintf('%21.2f [s]\n\n',toc(tStart));


% Step 3 : Reconstruction of the curve
%
% Now that the control points have been computed, the Bezier path can be
% reconstructed.
% 	- [curve_reconstruction]  reconstructs the Bezier path

	tStart = tic;
	disp('Reconstruction...');
	
	problem.curve = bezier_reconstruction(problem,t);
	
	fprintf('Bezier spline reconstructed in: '); 
	fprintf('%17.2f [s] \n\n',toc(tStart));
	
	
% Step 4 : Post processing
%
% You can also evaluate the curve velocity and acceleration 
% in order to visualize the C^1 continuity (and C^2 discontinuity) 
% of the reconstructed path.
% 	- [evaluate_velocity] 	  computes the velocity of the path
% 	- [evaluate_acceleration] computes the acceleration of the path

	%tStart = tic;
	problem.velocity = bezier_velocity(problem,t);
	%fprintf('   Velocity:       '); 
	%fprintf('%30.2f [s] \n',toc(tStart));
		
	%tStart = tic;
	problem.acceleration = bezier_acceleration(problem,t);
	%fprintf('   Acceleration:   '); 
	%fprintf('%30.2f [s] \n',toc(tStart));



% Step 5 : Visualisation and plots

	y = squeeze(problem.curve)';
	b = squeeze(problem.control)';
	p = squeeze(problem.data)';	
	
	a = problem.acceleration;
	v = problem.velocity;
	
	% Sphere
	[X,Y,Z] = sphere(); 
	figure;
	subplot(2,2,[1 3]); surf(0.95*X,0.95*Y,0.95*Z,...
			'FaceAlpha',0.7,'EdgeAlpha',1,...
			'FaceColor', [238 197 145]/255);
		hold on;
		plot3(y(:,1),y(:,2),y(:,3),'b','LineWidth',2);
		plot3(b(:,1),b(:,2),b(:,3),'.','Color',[0 0.7 0],'Markersize',30);
		plot3(p(:,1),p(:,2),p(:,3),'.r','Markersize',30);
		title('Bezier spline');
	subplot(222); plot(t(2:end-1),v,'-b','LineWidth',2); title('velocity');
	subplot(224); plot(t(2:end-1),a,'-b','LineWidth',2); title('acceleration');
	
	%% Acceleration and velocity
	%figure;
	%subplot(211); hold on;
	%plot(t(2:end-1),v,'-b','LineWidth',2);
	%subplot(212);
	%plot(t(2:end-1),a,'-b','LineWidth',2);
	%title('acceleration');

	
	
