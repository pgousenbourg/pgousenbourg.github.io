function a = bezier_acceleration(problem,t)
% Returns the value of the acceleration of the Bezier spline of the
% problem structure.
%
% function a = bezier_acceleration(problem)
%    returns a, the magnitude of the acceleration of the Bezier curve at
%    every point of the curve.
% 
% Input: problem, the structure of the approximation problem. It
%         contains problem.curve.
%        t, the time stamps at which the points of the curve are 
%         evaluated.
%                  
% Output: a, the curve acceleration as a vector of magnitudes.
%
% Original author: 
%   Pierre-Yves Gousenbourger, Oct. 19, 2016
% Contributors: 
%
% Change log:
% 	Oct. 19, 2016 (PYG):
%      Firts version
% 	Dec. 14, 2017 (PYG):
% 	   Modification for cubic splines
    
    y = problem.curve;
    k = size(y,3)-2;
    
    a = zeros(k,1);
    
    for i = 1:k
		log_left = problem.M.log(y(:,:,i+1),y(:,:,i));
		log_right = problem.M.log(y(:,:,i+1),y(:,:,i+2));
		hL = abs(t(i+1) - t(i));
		hR = abs(t(i+2) - t(i+1));
		diff = (log_left + log_right)./(hL*hR);
		a(i) = problem.M.norm(y(:,:,i+1),diff);
	end
	
end
