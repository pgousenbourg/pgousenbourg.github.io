% FUNCTION BSPLINE_RECONSTRUCTION(PB): 
% 		Reconstrucs the Bezier curve based on the interpolation points 
% 		and the control points given in the structure pb. 
% 		The piecewize Bezier curve is assumed to be composed of segments
% 		of degree 3 everywhere.
% 		The curve is reconstructed towards De Casteljau algorithm.
% ------------------------------------------------------------
% This file is part of the project "C1 bezier curves"
% 
% INPUT: 	PB: the structure of the interpolation problem containing:
%              * pb.control (cell{3n - 2})   : the control points;
%              * pb.t                        : the discretization of the
% 											   curve on each segment.
%
% OUTPUT: 	PB: The structure of the problem with pb.curve filled.
% ------------------------------------------------------------
% Author: Pierre-Yves Gousenbourger
% ------------------------------------------------------------
% Versions
% 	12/01/2013: first version.
% 	21/03/2013: final version for master thesis.
% 	30/02/2014: refactor for new structure.
% 	31/03/2016: cleaning and integration to new framework.
% 	06/03/2017: reconstruction_bspline
%               all pieces are cubic.


function pb = curve_reconstruction(pb)
    
    % data
    p        = pb.interp;
    b        = pb.control;
    t        = pb.t;
    n        = length(p);
    [m,k]    = size(p{1});
    
    % The curve is a different object following of the manifold.
    curve    = zeros(m,k,(n-1)*(t-1)+1);
    
    % Waitbar just because it is fun ^^.
    h = waitbar(0,'Starting the De Casteljau algorithm. Please wait...');
    
    %% De Casteljau
    % First segment
    %pp          = [p(1);b(1);p(2)];
    curve(:,:,1:t)  = de_casteljau(b(1:4),linspace(0,1,t),h,0,n-1);
    
    % Waitbar
    perc = 1/(n-1);
    waitbar(perc,h,sprintf(...
            'Processing the De Casteljau algorithm. Complete: %.f %%.',...
            perc*100));
    
    % Intern segments
    for i = 2:n-2;
        place_on_curve = (t-1)*(i-1)+1:(t-1)*i + 1;
        pp      = [b(3*(i-1)+1:3*i+1)];
        curve(:,:,place_on_curve) = ...
                                 de_casteljau(pp,linspace(0,1,t),h,perc,n-1);
        
        % Waitbar
        perc = i/(n-1);
        waitbar(perc,h,sprintf(...
            'Processing the De Casteljau algorithm. Complete: %.f %%.',...
            perc*100));
    end
    
    % Last segment
    pp = [b(end-3:end)];
    place_on_curve = (t-1)*(n-2) + 1: (t-1)*(n-1) + 1;
    curve(:,:,place_on_curve) = de_casteljau(pp,linspace(0,1,t),h,perc,n-1);
    
    % Waitbar
    waitbar(1,h,sprintf(...
        'Processing the De Casteljau algorithm. Complete: %.f %%.',...
        100));
    close(h);
    
    %% Store
    pb.curve = curve;
end
