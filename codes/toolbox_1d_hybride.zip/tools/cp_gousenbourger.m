function cp = cp_gousenbourger(problem, velocityMethod)
% Returns the control points of a Bezier curve interpolating the data of
% the problem with the method of Arnoudl2014.
%
% function cp = cp_gousenbourger(problem)
%    returns cp, a matrix of size [m,n,p] containing the control points
%    of the Bezier spline B interpolating the data points problem.data,
% 	 such that the following objective function is minimized
%
% 				       min ||ddot(B)||^2
% 
% Input: problem, the structure of the interpolation problem. It must
% 		 	contain the data points and the corresponding manifold.
% 		 velocityMethod, the method to set the velocities 
% 			(orthog, by default, or parallel).
%                   
% Output: cp, the control points, stored in a [m,n,p] matrix where
%         [m,n] is the size of an element of the manifold problem.M.name
%         and p is the index of the control point of the Bezier curve.
%
% Original author: 
%   Pierre-Yves Gousenbourger, Oct. 13, 2016
% Contributors: 
%
% Change log:
% 	Jan. 01, 2013 (PYG): 
% 		first version.
% 	Mar. 15, 2013 (PYG): 
% 		final version for master thesis.
% 	Mar. 03, 2016 (PYG): 
% 		cleaning and integration to new framework.
% 	Mar. 14, 2018 (PYG):
%      New version compatible with Manopt.

	
	if nargin < 2
		velocityMethod = 'orthog';
	end
    
    
    M = problem.M;
    data = problem.data;
    [l,c,n] = size(data);
    
    
    % Prepare control points
	Ncp  = 3*n-4;
	cp   = zeros(l,c,Ncp);		% control points
	dir  = zeros(l,c,n-2); 		% velocities directions
	
	
	
	% Compute the fixed velocities (orthogonal method)
    switch velocityMethod
	case 'parallel'
		for i = 2:n-1
			v = M.log(data(:,:,i-1),data(:,:,i+1));
			v = M.transp(data(:,:,i-1),data(:,:,i),v);
			dir(:,:,i-1) = v./(M.norm(data(:,:,i),v));
		end
	case 'orthog'
        for i = 2:n-1
			d = data(:,:,i);
			v1 = M.log(d,data(:,:,i-1));
			v2 = M.log(d,data(:,:,i+1));
			v  = v1 - v2;
			dir(:,:,i-1) = v./(M.norm(data(:,:,i),v));
		end
    otherwise; error('incorrect velocitytype parameter');
    end
	
	
	% Computation of the alphas
	alpha = alpha(M,data,dir);
	
	
	%% Control points computation
	cp(:,:,1) = data(:,:,1);
	cp(:,:,end) = data(:,:,end);
	
	for i = 2:n-1
		cp(:,:,3*(i-1)-1) = M.exp(data(:,:,i),-alpha(i-1)*dir(:,:,i-1));
		cp(:,:,3*(i-1))   = data(:,:,i);
		cp(:,:,3*(i-1)+1) = M.exp(data(:,:,i),alpha(i-1)*dir(:,:,i-1));
	end
	
	% first and last cp
	if n > 3
		cp(:,:,2)     = M.exp(data(:,:,2),    -(3/2)*alpha(1)*dir(:,:,1));
		cp(:,:,end-1) = M.exp(data(:,:,end-1), (3/2)*alpha(end)*dir(:,:,end));
	end
	
end


% Inner function : Matrix A and matrix B
function D  = alpha(M,data,v)

    n = size(data,3);
    A = sparse(n-2,n-2);
    b = zeros(n-2,1);
    
    if n > 3
		% First
		A(1,1:2) = [36*M.inner(data(:,:,2),v(:,:,1),v(:,:,1)),...
					 9*M.inner(data(:,:,2),v(:,:,1),M.transp(data(:,:,3),data(:,:,2),v(:,:,2)))];
					 
		s1 = M.log(data(:,:,2),data(:,:,3));
		s2 = M.log(data(:,:,2),data(:,:,1));
		b(1) = 9*M.inner(data(:,:,2),s1,v(:,:,1)) - 6*M.inner(data(:,:,2),s2,v(:,:,1));
				 
		% Last
		A(end,end-1:end) = [ 9*M.inner(data(:,:,end-1),v(:,:,end),M.transp(data(:,:,end-1),data(:,:,end-2),v(:,:,end-1))),...
							36*M.inner(data(:,:,end-1),v(:,:,end),v(:,:,end))];
							
		s1 = M.log(data(:,:,end-1),data(:,:,end-2));
		s2 = M.log(data(:,:,end-1),data(:,:,end));
		b(end) = -9*M.inner(data(:,:,end-1),s1,v(:,:,end)) + 6*M.inner(data(:,:,end-1),s2,v(:,:,end));
						
		% Intermediate
		for j = 2:n-3
			A(j,j-1:j+1) = [  M.inner(data(:,:,j)  ,v(:,:,j-1),M.transp(data(:,:,j+1),data(:,:,j),v(:,:,j))) ...
							4*M.inner(data(:,:,j+1),v(:,:,j)  ,v(:,:,j)) ...
							  M.inner(data(:,:,j+2),v(:,:,j+1),M.transp(data(:,:,j+1),data(:,:,j+2),v(:,:,j)))];
							  
			s = M.log(data(:,:,j),data(:,:,j+2));
			b(j) = M.inner(data(:,:,j+1),M.transp(data(:,:,j),data(:,:,j+1),s),v(:,:,j));
		end
	elseif n == 3
		A = 4*M.inner(data(:,:,2),v(:,:,1),v(:,:,1));
		b =   M.inner(data(:,:,2),M.transp(data(:,:,3),data(:,:,2),M.log(data(:,:,3),data(:,:,1))),v(:,:,1));
	else
		error('n < 3 !')
	end
	
	D = A\b;
end
