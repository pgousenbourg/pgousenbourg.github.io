function cp = cp_arnould(problem)
% Returns the control points of a Bezier curve interpolating the data of
% the problem with the method of Arnoudl2015.
%
% function cp = cp_arnould(problem)
%    returns cp, a matrix of size [m,n,p] containing the control points
%    of the Bezier spline B interpolating the data points problem.data,
% 	 such that the following objective function is minimized
%
% 				       min ||ddot(B)||^2
% 
% Input: problem, the structure of the interpolation problem. It must
% 		 contain the data points and the corresponding manifold.
%                   
% Output: cp, the control points, stored in a [m,n,p] matrix where
%         [m,n] is the size of an element of the manifold problem.M.name
%         and p is the index of the control point of the Bezier curve.
%
% Original author: 
%   Pierre-Yves Gousenbourger, Oct. 13, 2016
% Contributors: 
%
% Change log:
% 	Oct. 13, 2016 (PYG):
%      First version
% 	Mar. 14, 2018 (PYG):
%      New version compatible with Manopt

	M = problem.M;
    data = problem.data;
    [l,c,n] = size(data);
    
    
    % Prepare control points
	Ncp  = 3*n-4;
	cp   = zeros(l,c,Ncp);
	
	
	% Compute the matrix D
	switch n
	case 2; % nothing to do
	case 3; D = [1/4 1 -1/4];
	case 4; A = [8 3; 2 12]; C = [2 9 0 0; 0 5 11 -2]; D = inv(A)*C;
	otherwise; D = compute_D(n);
	end
	
	
	
	% Inner function - projection of data on the tangent space of d.
	function Tdata = Tdata(d)
		Tdata = zeros(size(data));
		for k = 1:n
			Tdata(:,:,k) = M.log(d,data(:,:,k));
		end
	end
	
	
	
	% Compute the control points
	cp(:,:,[1,end]) = data(:,:,[1,end]);
	switch n
    case 2; cp = data; % just a geodesic;
    case 3;
		d = data(:,:,2);
		Tbm = cpGen(D,Tdata(d));
		cp(:,:,2) = M.exp(d,Tbm);
		cp(:,:,4) = M.exp(d,-Tbm);
		cp(:,:,3) = d;
	otherwise
		for i = 2:n-1
			d = data(:,:,i);
			Tbm = cpGen(D(i-1,:),Tdata(d));
			cp(:,:,3*(i-1)-1) = M.exp(d,Tbm);
			switch i
			case 2;	   cp(:,:,3*(i-1)+1) = M.exp(d,-2/3*Tbm);
			case n-1;  cp(:,:,3*(i-1)+1) = M.exp(d,-3/2*Tbm);
			otherwise; cp(:,:,3*(i-1)+1) = M.exp(d,-Tbm);
			end
			cp(:,:,3*(i-1)) = d;
		end
	end
end


% Computes the D matrix for the interpolation
function D = compute_D(n)
	A = sparse(n-2,n-2);
	C = sparse(n-2,n);
	
	A(1,1:2) = [64 24];
	C(1,1:2) = [16 72];
	
	A(2,1:3) = [24 144 36];
	C(2,2:3) = [60 144];
	
	for i = 3:n-3
		A(i,i-1:i+1) = [36 144 36];
		C(i,i:i+1) = [72 144];
	end
	
	A(end,end-1:end) = [36 144];
	C(end,end-2:end) = [72 132 -24];
	
	D = inv(A)*C;
end


% Auxiliary function to compute the weighted sums
function y = cpGen(w,Tdata)
	[a,b,~,~] = size(Tdata);
	% weights
	w = reshape(full(w),1,1,length(w));
	w = repmat(w,[a,b,1]);

	% weighted sum
	y = sum(w.*Tdata,3);
end
