function v = bezier_velocity(problem,t)
% Returns the value of the velocity of the Bezier spline of the
% problem structure.
%
% function v = bezier_velocity(problem)
%    returns v, the magnitude of the velocity of the Bezier curve at
%    every point of the curve.
% 
% Input: problem, the structure of the approximation problem. It
%         contains problem.curve.
%        t, the time stamps at which the points of the curve are 
%         evaluated.
%                  
% Output: v, the curve velocity as a vector of magnitudes.
%
% Original author: 
%   Pierre-Yves Gousenbourger, Oct. 19, 2016
% Contributors: 
%
% Change log:
% 	Oct. 19, 2016 (PYG):
%      First version
% 	Dec. 14, 2017 (PYG):
% 	   Modification for cubic splines
    
    y = problem.curve;
    k = size(y,3)-2;
    
    v = zeros(k,1);
    cv = zeros(size(y,1),size(y,2),size(y,3)-2);
    
    for i = 1:k
		log_vec = problem.M.log(y(:,:,i),y(:,:,i+2));
		h = (t(i+2) - t(i));
		diff = log_vec./h;
		cv(:,:,i) = diff;
		v(i) = problem.M.norm(y(:,:,i),diff);
	end
	
	%cv = squeeze(cv)';
	
	%size(cv)
	%size(t)
	
	%plot(t(2:end-1),cv(:,1),'b'); hold on;
	%plot(t(2:end-1),cv(:,2),'r');
	%plot(t(2:end-1),cv(:,3),'k');
	
end
